package com.example.memory_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
