import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'components/game_utils.dart';
import 'components/info_card.dart';
import 'components/dialog_util.dart';
import 'components/login.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:page_transition/page_transition.dart';

void main() {
  runApp(const MyApp());
  List<Map> richMan = [
    {
      "url": "images/new1.png",
      "isSelect": false,
    },
    {
      "url": "images/new4.png",
      "isSelect": false,
    }
  ];

  if (richMan[0].containsKey('url')) {
    print("yeah contains ");
  } else {
    print("doesnt  friend");
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Memory Game',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        debugShowCheckedModeBanner: false,
        home: const GameLoginPage());
  }

}

// const GameLoginPage(),