import 'package:flutter/material.dart';
import 'memory_game.dart';
import 'package:animated_text_kit/animated_text_kit.dart';

class GameLoginPage extends StatefulWidget {
  const GameLoginPage({Key? key}) : super(key: key);

  @override
  _LoginPage createState() => _LoginPage();
}

class _LoginPage extends State<GameLoginPage> {
  List<MaterialColor> colorizeColors = [
    Colors.red,
    Colors.amber,
    Colors.yellow,
  ];

  static const colorizeTextStyle =
      TextStyle(fontSize: 25.0, fontFamily: 'SF', color: Colors.redAccent);
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _getAppBar(),
      body: playGame(),
    );
  }

  Widget playGame() {
    return SingleChildScrollView(
      child: Stack(
        children: [
          Container(
            margin: EdgeInsets.all(10),
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(20.0)),
              image: DecorationImage(
                image: AssetImage("images/X-mas.jpeg"),
                fit: BoxFit.fill,
              ),
              color: Colors.grey.withOpacity(0.2),
            ),
            height: 400,
          ),
          Column(
            children: <Widget>[
              Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(bottom: 20),
                  padding: new EdgeInsets.only(top: 5),
                  child: Text(
                    "Memory Game",
                    style: TextStyle(
                      color: Colors.deepOrange,
                      fontSize: 48,
                      fontWeight: FontWeight.bold,
                      fontStyle: FontStyle.normal,
                      fontFamily: 'Modern Love',
                    ),
                  ),
                  height: 80),
              SizedBox(
                height: 30.0,
              ),
              Container(
                margin: EdgeInsets.only(bottom: 30, left: 25, right: 25),
                alignment: Alignment.center,
                child: Center(
                 child: Text(
                      "Test your Memory Photographic Capacity. Cards are being Shuffled. Turn over two cards that do match and get scored",
                       style: TextStyle(color: Colors.deepOrange[900], fontSize: 22, fontWeight: FontWeight.bold),
                       textAlign: TextAlign.center,
                      ),
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  ElevatedButton(
                    onPressed: () {
                      mygamePage();
                    },
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(
                          horizontal: 40.0, vertical: 20.0),
                      primary: Colors.deepOrange,
                      shape: StadiumBorder(),
                    ),
                    child: Text(
                      "START",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: 'Modern Love'),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }

  AppBar _getAppBar() {
    return AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Center(
          child: Image(
            image: AssetImage("images/logo.png"),
          ),
        ));
  }

  mygamePage() {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => GamePage()));
  }
}
